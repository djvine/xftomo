# This is a simple python package for reconstructing tomographic datasets using flitered back projection

Data are read in from HDF5 in the case where a single h5 file contains all data and for the case when each projection is stored in a separate h5.

The projections are aligned and then tomograms reconstructed.
